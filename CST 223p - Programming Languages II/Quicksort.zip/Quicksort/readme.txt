========================================================================
    Console AppWizard : Quicksort Project Overview
========================================================================

Console AppWizard has created this Quicksort project for you as a starting point. This project contains 
a simple console application without pre-compiled headers. If you wish to create a console 
application using pre-compiled headers, please use the Visual C++ Win32 Project Wizard.

This file contains a summary of what you will find in each of the files that make up your project.

Quicksort.vcproj :
    This is the main project file for projects generated using an Application Wizard. 
    It contains information about the version of the product that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

Quicksort.cpp : 
    Defines the entry point for the console-mode application.

readme.txt : 
    This text file.
