//--------------------------------------------------------------------
// Author:         Matthew Klump CST 211 Lab #9
// Date Created:   August 26, 2002
// Last Change Date:  August 26, 2002
// Project:        Ordered List
// Filename:       Exercise2&3-SetSTL.cpp
//
// Overview:  Test program that merges two sets, and checks for a set
//			  being a subset of another set Structure of the standard
//			  template library.
//     
//--------------------------------------------------------------------

#include <iostream>
#include <set>

using namespace std;

//--------------------------------------------------------------------

class TestData
{
  public:

    void setKey ( char newKey )
        { keyField = newKey; }   // Set the key

    char key () const
        { return keyField; }     // Returns the key

  private:

     char keyField;              // Key for the element
};

bool subset ( const set<TestData> &Set,
			  const set<TestData> &subSet )
{
	int found = 0;
	set<TestData,char>::iterator pos2, pos1;

	for(pos2 = subSet.begin(),
		pos1 = Set.begin(); pos2 != subSet.end(); ++pos1)
	{
		if( pos1 == Set.end() )
			++pos2;
		if( pos1 == *pos2 )
			++found;
	}
	if( found >= subSet.size )
		return true;
	else
		return false;
}

//--------------------------------------------------------------------

void main()
{
    set<TestData,char> testList1,         // Test lists
                       testList2;
    TestData testElement;                 // List element
    char ch;                              // Input character

    cout << endl << "Enter first list of characters (no spaces) : ";
    cin.get(ch);
    while ( ch != '\n' )
    {
        testElement.setKey(ch);
        testList1.insert(testElement);
        cin.get(ch);
    }

    cout << endl << "Enter second list of characters (no spaces) : ";
    cin.get(ch);
    while ( ch != '\n' )
    {
        testElement.setKey(ch);
        testList2.insert(testElement);
        cin.get(ch);
    }

    cout << endl << "List 1 : " << endl;
	// print testList1
    copy(testList1.begin(),testList1.end(),
		 ostream_iterator<int>(cout," "));
    cout << endl << "List 2 : " << endl;
    copy(testList2.begin(),testList2.end(),
		 ostream_iterator<int>(cout," "));

	char input;
	cout << endl << "Please enter m for the merge Lists test," << endl
				 << "s for the sub-List test, or b for both tests at" << endl
				 << "once, or q to quit" << endl;
	do
	{
		cout << "Selection?: ";
		cin >> input;
		switch (input)
		{
		case 'm': case 'M':
			// Merge list 2 into list 1.
			copy(testList1.begin(),testList1.end(),
				 inserter(testList2,testList2.begin()));
			cout << endl << "After merge -- List 1 : " << endl;
			copy(testList1.begin(),testList1.end(),
				ostream_iterator<int>(cout," "));
			break;
		
		case 's': case 'S':
			// Check whether list 2 is a subset of list 1.
			cout << endl;
			if ( testList1.subset(testList2) )
				cout << "List 2 is a subset of list 1" << endl << endl;
			else
				cout << "List 2 is NOT a subset of list 1" << endl << endl;
			break;

		case 'b': case 'B':
			// Merge list 2 into list 1.
			copy(testList1.begin(),testList1.end(),
				 inserter(testList2,testList2.begin()));
			cout << endl << "After merge -- List 1 : " << endl;
			copy(testList1.begin(),testList1.end(),
				ostream_iterator<int>(cout," "));
			// Check whether list 2 is a subset of list 1.
			cout << endl;
			if ( testList1.subset(testList2) )
				cout << "List 2 is a subset of list 1" << endl;
			else
				cout << "List 2 is NOT a subset of list 1" << endl;
			break;
		}
	}
	while( input != 'q' && input != 'Q' );
}