/*
------------------------------------------------------------------
/// Author:         Matthew Klump for CST 407 JAVA J2EE
/// Date Created:   April 26, 2004
/// Last Change Date: April 26, 2004
/// Project:        Assignment #2, 9.3 & 9.7
/// Filename:       CookieServlet.java
///
/// Overview:
///       This program uses cookies to store data on the
///       client computer.
///
/// Input:
///       Input is accepted for the user by way if four
///       radio buttons for selecting a language.
/// Output:
///       The output of this program is displayed on the
///       client's browser window.
-------------------------------------------------------------------
 */
// Fig. 9.20: CookieServlet.java
// Using cookies to store data on the client computer.
package com.deitel.advjhtp1.servlets;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class CookieServlet extends HttpServlet 
{
    private final Map books = new HashMap();
    
    // initialize Map books
    public void init() {
        books.put( "C", "0130895725 Price: $59.95" );
        books.put( "C++", "0130895717 Price: $69.95" );
        books.put( "Java", "0130125075 Price: $89.95" );
        books.put( "VB6", "0134569555 Price: $79.95" );
    }
    
   // receive language selection and send cookie containing
   // recommended book to the client
   protected void doPost( HttpServletRequest request,
      HttpServletResponse response )
         throws ServletException, IOException
   {
      String language = request.getParameter( "language" );
      String isbn = books.get( language ).toString();
      Cookie cookie = new Cookie( language, isbn );

      response.addCookie( cookie );  // must precede getWriter 
      response.setContentType( "text/html" );
      PrintWriter out = response.getWriter();         

      // send XHTML page to client

      // start XHTML document
      out.println( "<?xml version = \"1.0\"?>" );

      out.println( "<!DOCTYPE html PUBLIC \"-//W3C//DTD " +
         "XHTML 1.0 Strict//EN\" \"http://www.w3.org" +
         "/TR/xhtml1/DTD/xhtml1-strict.dtd\">" ); 

      out.println( 
         "<html xmlns = \"http://www.w3.org/1999/xhtml\">" );
      
      // head section of document
      out.println( "<head>" );
      out.println( "<title>Welcome to Cookies</title>" );      
      out.println( "</head>" );

      // body section of document
      out.println( "<body>" );
      out.println( "<p>Welcome to Cookies! You selected " +
         language + "</p>" );

      out.println( "<p><a href = " +
         "\"/advjhtp1/servlets/CookieSelectLanguage.html\">" +
         "Click here to choose another language</a></p>" );

      out.println( "<p><a href = \"/advjhtp1/cookies\">" + 
         "Click here to get book recommendations</a></p>" );
      out.println( "</body>" );

      // end XHTML document
      out.println( "</html>" );
      out.close();    // close stream
   }
    
    // read cookies from client and create XHTML document
    // containing recommended books
    protected void doGet( HttpServletRequest request,
    HttpServletResponse response )
    throws ServletException, IOException
    {
        Cookie cookies[] = request.getCookies();  // get cookies
        int book_number = 0;
        
        response.setContentType( "text/html" );
        PrintWriter out = response.getWriter();
        
        // start XHTML document
        out.println( "<?xml version = \"1.0\"?>" );
        
        out.println( "<!DOCTYPE html PUBLIC \"-//W3C//DTD " +
        "XHTML 1.0 Strict//EN\" \"http://www.w3.org" +
        "/TR/xhtml1/DTD/xhtml1-strict.dtd\">" );
        
        out.println(
        "<html xmlns = \"http://www.w3.org/1999/xhtml\">" );
        
        // head section of document
        out.println( "<head>" );
        out.println( "<title>Recommendations</title>" );
        out.println( "</head>" );
        
        // body section of document
        out.println( "<body>" );
        
        // if there are any cookies, recommend a book for each ISBN
        if ( cookies != null && cookies.length != 0 )
        {
            out.println( "<h1>Recommendations</h1>" );
            out.println( "<form action=\"/advjhtp1/Process_Order\" " +
                "method=\"post\">" );
                
            out.println( "<p>Select the books you with to purchase:</p>" );
            out.println( "<p>" );
            // get the name of each cookie
            for ( int i = 0; i < cookies.length; i++ )
                out.println( cookies[ i ].getName() +
                " How to Program. ISBN#: " +
                cookies[ i ].getValue() + " <input type=\"checkbox\" name=\"book"
                + ++book_number + "\" value=\"" +
                cookies[ i ].getValue() +
                "\"><br />" );
            
            out.println( "<br /><input type=\"submit\" value=\"PLACE PURCHASE\">" );
            out.println( "</p></form>" );
        }
        else
        {   // there were no cookies
            out.println( "<h1>No Recommendations</h1>" );
            out.println( "<p>You did not select a language.</p>" );
        }
        out.println( "</body>" );
        
        // end XHTML document
        out.println( "</html>" );
        out.close();    // close stream
    }
}