/*
------------------------------------------------------------------
/// Author:         Matthew Klump for CST 407 JAVA J2EE
/// Date Created:   April 26, 2004
/// Last Change Date: April 26, 2004
/// Project:        Assignment #2, 9.3 & 9.7
/// Filename:       ProcessBookOrder.java
///
/// Overview:
///       This program uses cookies to store data on the
///       client computer.
///
/// Input:
///       Input is accepted from the CookieServlet in the
///       over-ridden doGet method.
/// Output:
///       The output of this program is displayed on the
///       client's browser window.
-------------------------------------------------------------------
*/
// Fig. 9.20: CookieServlet.java
// Using cookies to store data on the client computer.
package com.deitel.advjhtp1.servlets;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class ProcessBookOrder extends HttpServlet
{
   protected void doPost( HttpServletRequest request,
      HttpServletResponse response )
         throws ServletException, IOException
   {
      String book[] = new String[5];
      for( int x = 1; x < 5; x++ )
          book[x] = request.getParameter( "book" + String.valueOf(x) );

      response.setContentType( "text/html" );
      PrintWriter out = response.getWriter();
      
//      for( int x = 0; x < 5; ++x )
//      {
//          out.println( book[x] + "<br />" );
//      }

      // send XHTML page to client

      // start XHTML document
      out.println( "<?xml version = \"1.0\"?>" );

      out.println( "<!DOCTYPE html PUBLIC \"-//W3C//DTD " +
         "XHTML 1.0 Strict//EN\" \"http://www.w3.org" +
         "/TR/xhtml1/DTD/xhtml1-strict.dtd\">" ); 

      out.println( 
         "<html xmlns = \"http://www.w3.org/1999/xhtml\">" );
      
      // head section of document
      out.println( "<head>" );
      out.println( "<title>Order Summary</title>" );      
      out.println( "</head>" );

      // body section of document
      out.println( "<body>" );
      out.println( "<h1>Your Order:</h1>" );
      out.println( "<p>" );
      
      double total = 0.0;
      for( int x = 1; x < 5; x++ )
      {
          if( book[x] != null )
          {
              if( book[x].startsWith( "0130895725" ) )
              {
                  out.println( "C How to Program. ISBN#: " + 
                  "0130895725 Price: $59.95<br />" );
                  total += 59.95;
              }
              else if( book[x].startsWith( "0130895717" ) )
              {
                  out.println( "C++ How to Program. ISBN#: " + 
                  "0130895717 Price: $69.95<br />" );
                  total += 69.96;
              }
              else if( book[x].startsWith( "0130125075" ) )
              {
                  out.println( "Java How to Program. ISBN#: " + 
                  "0130125075 Price: $89.95<br />" );
                  total += 89.95;
              }
              else if( book[x].startsWith( "0134569555" ) )
              {
                  out.println( "VB6 How to Program. ISBN#: " + 
                  "0134569555 Price: $79.95<br />" );
                  total += 79.97;
              }
          }
      }
      out.println( "<br />Your total is $" + total +
                   "<br /><h2>THANK YOU!</h2>" );

      out.println( "</p></body>" );
      // end XHTML document
      out.println( "</html>" );
      out.close();    // close stream
   }
}
