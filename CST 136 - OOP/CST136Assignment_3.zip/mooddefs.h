// Name: Dom Virgilio and Modified by Matthew Klump for CST 136 Assignment #3 Part 2
// Class: CST 136
// Assignment #2

// moodtypes.h: interface for the CMoodMgr class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MOODTYPES_H__D6719E75_0E79_4F9C_BDE9_147A1FA48DC7__INCLUDED_)
#define AFX_MOODTYPES_H__D6719E75_0E79_4F9C_BDE9_147A1FA48DC7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define SONG_SECURE 1
#define SONG_PROMO 2

#endif // !defined(AFX_MOODTYPES_H__D6719E75_0E79_4F9C_BDE9_147A1FA48DC7__INCLUDED_)