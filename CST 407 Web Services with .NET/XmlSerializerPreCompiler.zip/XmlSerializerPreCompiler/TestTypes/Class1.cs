using System;

namespace TestTypes {
  public class Class1 {
    int x = 2;
    int y = 4;
  }
}
