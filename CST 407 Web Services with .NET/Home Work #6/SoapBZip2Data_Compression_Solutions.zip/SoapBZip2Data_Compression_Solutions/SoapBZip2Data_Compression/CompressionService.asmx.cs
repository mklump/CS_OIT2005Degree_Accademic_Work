using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.IO;
using System.Web.Services;
using System.Web.Services.Protocols;
// BZip2 namespace specific:
using ICSharpCode.SharpZipLib.BZip2;

namespace SoapBZip2Data_Compression
{
	/// <summary>
	/// Summary description for CompressionService.
	/// </summary>
	[WebService(Namespace="http://localhost/mywebprojects/SoapBZip2Data_Compression")]
	public class CompressionService : System.Web.Services.WebService
	{
		public ClassLargeStructure structure;
		public CompressionService()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
			structure = new ClassLargeStructure();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		[WebMethod]
		public void SetLargeStructure( decimal [] your_structure )
		{
			structure.data = your_structure;
		}

		[WebMethod]
		public decimal[] GetLargeStructure()
		{
			return structure.data;
		}
	}
	/// <summary>
	/// Class ClassLargeStructure
	/// </summary>
	public class ClassLargeStructure
	{
		public decimal [] data;
		private Random rand;

		/// <summary>
		/// Default constructor
		/// </summary>
		public ClassLargeStructure()
		{
			rand = new Random();
			data = new decimal[999999];
			for( int x = 0; x < data.Length; ++x )
			{
				byte [] bytes = new byte[12];
				rand.NextBytes( bytes );
				data[x] = Convert.ToDecimal( bytes );
			}
		}
	}
	
	/// <summary>
	/// Class CompressionExtensionAttribute
	/// </summary>
	[AttributeUsage(AttributeTargets.Method)]
	public class CompressionExtensionAttribute : SoapExtensionAttribute
	{
		private int priority;

		/// <summary>
		/// ExtensionType Override
		/// </summary>
		public override Type ExtensionType
		{
			get
			{
				return typeof(CompressionExtension);
			}
		}
		/// <summary>
		/// Priority Integer Override
		/// </summary>
		public override int Priority
		{
			get
			{
				return priority;
			}
			set
			{
				priority = value;
			}
		}
		/// <summary>
		/// Default constructor
		/// </summary>
		public CompressionExtensionAttribute()
		{
		}
	}
	
	/// <summary>
	/// Class CompressionExtension
	/// </summary>
	public class CompressionExtension : SoapExtension
	{
		public Stream oldStream;
		public MemoryStream newStream;

		/// <summary>
		/// Default constructor
		/// </summary>
		public CompressionExtension()
		{
			oldStream = null;
			newStream = null;
		}
		/// <summary>
		/// Must be overriden
		/// </summary>
		/// <param name="methodInfo"></param>
		/// <param name="attribute"></param>
		/// <returns></returns>
		public override object GetInitializer(
									LogicalMethodInfo methodInfo,
									SoapExtensionAttribute attribute)
		{
			return null;
		}
		/// <summary>
		/// Another required override
		/// </summary>
		/// <param name="serviceType"></param>
		/// <returns></returns>
		public override object GetInitializer(Type serviceType)
		{
			return null;
		}
		/// <summary>
		/// Yet another required override
		/// </summary>
		/// <param name="initializer"></param>
		public override void Initialize(object initializer)
		{	
		}
		/// <summary>
		/// And now the method we've needed all along...
		/// </summary>
		/// <param name="message"></param>
		public override void ProcessMessage(SoapMessage message)
		{
			switch(message.Stage)
			{
				case SoapMessageStage.BeforeSerialize:
					break;
				case SoapMessageStage.AfterSerialize:
					BZip2.Compress( oldStream, newStream, 1 );
					break;
				case SoapMessageStage.BeforeDeserialize:
					BZip2.Decompress( oldStream, newStream );
					break;
				case SoapMessageStage.AfterDeserialize:
					break;
				default:
					break;
			}
		}
		/// <summary>
		/// Needed to replace the network stream with
		/// my own buffered stream.
		/// </summary>
		/// <param name="stream"></param>
		/// <returns></returns>
		public override Stream ChainStream(Stream stream)
		{
			oldStream = stream;
			newStream = new MemoryStream();
			return newStream;
		}

	}
}
