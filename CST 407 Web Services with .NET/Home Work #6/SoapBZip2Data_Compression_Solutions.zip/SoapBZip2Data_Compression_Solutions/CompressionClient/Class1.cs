using System;
using CompressionClient.localhost;

namespace CompressionClient
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			CompressionService service = new CompressionService();
			decimal[] decimals = service.GetLargeStructure();
			for( int x = 0; x < 10; ++x )
			{
				Console.WriteLine("{0}", decimals[x].ToString() );
			}
			decimal [] newdecimals = { 201, 301, 401, 501, 601, 701, 801, 901, 1001, 1101 };
			service.SetLargeStructure( newdecimals );
			newdecimals = service.GetLargeStructure();
			for( int x = 0; x < 10; ++x )
			{
				Console.WriteLine("{0}", newdecimals[x].ToString() );
			}
		}
	}
}
