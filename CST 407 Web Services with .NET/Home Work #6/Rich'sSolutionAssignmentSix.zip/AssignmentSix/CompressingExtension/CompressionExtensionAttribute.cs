using System;
using System.Web.Services.Protocols;

namespace CompressingExtension {
	[AttributeUsage( AttributeTargets.Method )]
	public class CompressionExtensionAttribute : SoapExtensionAttribute {
		private int priority;

		public override int Priority {
			get { return priority; }
			set { priority = value; }
		}

		public override Type ExtensionType {
			get { return typeof( CompressionExtension ); }
		}
	}
}
