#region Using Block
	using ICSharpCode.SharpZipLib.BZip2;
	using System;
	using System.IO;
	using System.Web.Services.Protocols;
	using System.Xml;
#endregion

namespace CompressingExtension {
	public class CompressionExtension : SoapExtension {
		Stream       oldStream;
		MemoryStream newStream;

		public override object GetInitializer( Type serviceType ) {
			return null;
		}

		public override object GetInitializer( LogicalMethodInfo methodInfo,
											   SoapExtensionAttribute attribute ) {
			return null;
		}

		public override void Initialize( object initializer ) {
		}

		public override Stream ChainStream( Stream stream ) {
			oldStream = stream;
			newStream = new MemoryStream();
			return newStream;
		}

		public override void ProcessMessage( SoapMessage message ) {
			switch( message.Stage ) {
				case SoapMessageStage.BeforeSerialize:
					break;
				case SoapMessageStage.AfterSerialize:
					this.ProcessOutbound();
					break;
				case SoapMessageStage.BeforeDeserialize:
					this.ProcessInbound();
					break;
				case SoapMessageStage.AfterDeserialize:
					break;
			}
		}

		private void ProcessOutbound() {
			Stream stream = newStream;
			stream.Position = 0;
			StreamReader sr = new StreamReader( stream );

			XmlDocument xdoc = new XmlDocument();
			xdoc.LoadXml( sr.ReadToEnd() );

			try {
				XmlNamespaceManager xnm = new XmlNamespaceManager( xdoc.NameTable );
				xnm.AddNamespace( "soap", "http://schemas.xmlsoap.org/soap/envelope/" );
				XmlNode body = xdoc.SelectSingleNode( "//soap:Body", xnm );
				if( body.ChildNodes[0].InnerXml.Length >= 8 ) {
					body.ChildNodes[0].InnerXml = this.Compress( body.ChildNodes[0].InnerXml );
				}
			} catch( Exception e ) {
				System.Diagnostics.Debug.Write( e.ToString() );
			}

			MemoryStream ms = new MemoryStream();
			XmlTextWriter xtw = new XmlTextWriter( ms, System.Text.Encoding.UTF8 );
			string check = Convert.ToBase64String( ms.ToArray() );

			xdoc.Save( xtw );
			ms.Position = 0;
			Copy( ms, oldStream );
		}

		private void ProcessInbound() {
			Stream stream = oldStream;
			StreamReader sr = new StreamReader( stream, System.Text.Encoding.ASCII );

			XmlDocument xdoc = new XmlDocument();
			xdoc.LoadXml( sr.ReadToEnd() );

			try {
				XmlNamespaceManager xnm = new XmlNamespaceManager( xdoc.NameTable );
				xnm.AddNamespace( "soap", "http://schemas.xmlsoap.org/soap/envelope/" );
				XmlNode body = xdoc.SelectSingleNode( "//soap:Body", xnm );
				if( body.ChildNodes[0].InnerXml.Length >= 8 ) {
					body.ChildNodes[0].InnerXml = this.Decompress( body.ChildNodes[0].InnerXml );
				}
			} catch( Exception e ) {
				System.Diagnostics.Debug.Write( e.ToString() );
			}

			MemoryStream ms = new MemoryStream();
			XmlTextWriter xtw = new XmlTextWriter( ms, System.Text.Encoding.UTF8 );
			string check = Convert.ToBase64String( ms.ToArray() );

			xdoc.Save( xtw );
			ms.Position = 0;
			Copy( ms, newStream );
			newStream.Position = 0;
		}

		private string Decompress( string text ) {
			MemoryStream ms = new MemoryStream( Convert.FromBase64String( text ) );
			BZip2InputStream bZipInput = new BZip2InputStream( ms );
			byte[] uncompressedBytes = new byte[bZipInput.Length];
			bZipInput.Read( uncompressedBytes, 0, (int) bZipInput.Length );
			bZipInput.Close();
			ms.Close();

			string uncompressedString = System.Text.Encoding.UTF8.GetString( uncompressedBytes );
			return uncompressedString.Trim( new char[] { '\0' } );
		}

		private string Compress( string uncompressedString ) {
			MemoryStream ms = new MemoryStream();
			Stream bZipOutput = new BZip2OutputStream( ms );
			bZipOutput.Write( 
				System.Text.Encoding.UTF8.GetBytes( uncompressedString  ),
				0, uncompressedString.Length );
			bZipOutput.Close();
			return Convert.ToBase64String( ms.ToArray() );
		}

		void Copy( Stream from, Stream to ) {
			TextReader reader = new StreamReader( from );
			TextWriter writer = new StreamWriter( to );
			writer.WriteLine( reader.ReadToEnd() );
			writer.Flush();
		}
	}
}
