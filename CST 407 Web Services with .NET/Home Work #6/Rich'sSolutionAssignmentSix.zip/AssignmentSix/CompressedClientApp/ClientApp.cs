using CompressedClientApp.CompressedWS;
using ICSharpCode.SharpZipLib.BZip2;
using System;
using System.IO;

namespace CompressedClientApp {
	class ClientApp {
		[STAThread]
		static void Main(string[] args) {
			byte[] bytes2 = System.Text.Encoding.UTF8.GetBytes( "now is the time for all good people to come to the aid of their country." );
			CompressedWebService cws = new CompressedWebService();
			string answer = cws.HelloWorld();
			Console.WriteLine( answer );
			Console.ReadLine();
		}
	}
}
