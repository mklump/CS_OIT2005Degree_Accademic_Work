ALTER INDEX ALL
ON Production.TransactionHistory
REORGANIZE;
