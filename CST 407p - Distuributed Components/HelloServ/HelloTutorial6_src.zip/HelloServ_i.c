/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Aug 07 18:13:40 2000
 */
/* Compiler settings for E:\Brian Hart\Samples\HelloServ\HelloServ.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IHelloWorld = {0x706A50D1,0x6C74,0x11D4,{0xA3,0x59,0x00,0x10,0x4B,0x73,0x24,0x42}};


const IID LIBID_HELLOSERVLib = {0x27613737,0x6A27,0x11D4,{0xA3,0x58,0x00,0x10,0x4B,0x73,0x24,0x42}};


const IID DIID_DHelloWorldEvents = {0x706A50D4,0x6C74,0x11D4,{0xA3,0x59,0x00,0x10,0x4B,0x73,0x24,0x42}};


const CLSID CLSID_HelloWorld = {0x706A50D3,0x6C74,0x11D4,{0xA3,0x59,0x00,0x10,0x4B,0x73,0x24,0x42}};


#ifdef __cplusplus
}
#endif

