//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by HelloCli.rc
//
#define IDD_HELLOCLI_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME1                  129
#define IDR_MAINFRAME2                  130
#define IDC_START_SERVER                1000
#define IDC_ADVISE_SERVER               1001
#define IDC_CALL_METHOD                 1002
#define IDC_UNADVISE_SERVER             1003
#define IDC_STOP_SERVER                 1004
#define IDC_STATUS                      1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
